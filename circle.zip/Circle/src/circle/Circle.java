/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package circle;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.WindowConstants;
import java.awt.geom.Ellipse2D;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Admin
 */
public class Circle extends JPanel{
    
    public JFrame frame;
    public static int x = 20;
    public static int width = 20;
    public Circle(){
       frame = new JFrame();
       frame.setLocation(100, 50);
       frame.setMinimumSize(new Dimension(600,600));
       frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
       
       frame.getContentPane().add(this); 
       
       frame.pack();
       frame.setVisible(true);
       frame.repaint();
   }
    
    public void paintComponent(Graphics g){
       super.paintComponent(g);
       Graphics2D g2 = (Graphics2D) g;
       
       Ellipse2D circle = new Ellipse2D.Double(x,200,width,170);
       
       g2.setPaint(Color.MAGENTA);
       g2.fill(circle);
       g2.draw(circle);
   } 
   
   
    public static void main(String[] args) {
        Circle fr = new Circle();
       
        while(true) {
            for(int i = 0; i<150; i++){
            try {
                Thread.sleep(10);
            } catch (InterruptedException ex) {
                Logger.getLogger(Circle.class.getName()).log(Level.SEVERE, null, ex);
            }
            x++;
            width++;
            fr.repaint();
            }
            for(int i = 0; i<150; i++){
                try {
                    Thread.sleep(10);
                } catch (InterruptedException ex) {
                    Logger.getLogger(Circle.class.getName()).log(Level.SEVERE, null, ex);
                }
                x+=2;
                width--;
                fr.repaint();
            }
            for(int i = 0; i<150; i++){
                try {
                    Thread.sleep(10);
                } catch (InterruptedException ex) {
                    Logger.getLogger(Circle.class.getName()).log(Level.SEVERE, null, ex);
                }
                x-=2;
                width++;
                fr.repaint();
            }
            for(int i = 0; i<150; i++){
                try {
                    Thread.sleep(10);
                } catch (InterruptedException ex) {
                    Logger.getLogger(Circle.class.getName()).log(Level.SEVERE, null, ex);
                }
                x--;
                width--;
                fr.repaint();
            }
        }
        
        
    }
    
}
